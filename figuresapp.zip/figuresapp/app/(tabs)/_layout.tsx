import FontAwesome from '@expo/vector-icons/FontAwesome';
import { Link, Tabs } from 'expo-router';
import { Pressable, TouchableOpacity, useColorScheme } from 'react-native';

import Colors from '../../constants/Colors';
import { Ionicons } from '@expo/vector-icons';
import { AuthContext } from '../context/authContext';
import { useContext } from 'react';

/**
 * You can explore the built-in icon families and icons on the web at https://icons.expo.fyi/
 */
function TabBarIcon(props: {
  name: React.ComponentProps<typeof FontAwesome>['name'];
  color: string;
}) {
  return <FontAwesome size={28} style={{ marginBottom: -3 }} {...props} />;
}

export default function TabLayout() {
  const { logout } = useContext(AuthContext);
  const colorScheme = useColorScheme();

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: Colors[colorScheme ?? 'light'].tint,
      }}>
      <Tabs.Screen
        name="index"
        options={{
          title: 'Figures',
          tabBarIcon: ({ color }) => <TabBarIcon name="cube" color={color} />,
          headerRight: () => (
            <TouchableOpacity
              style={{ paddingRight: 12 }}
              onPress={logout}
            >
              <Ionicons name='log-out' color='#00ACC9' size={24} />
            </TouchableOpacity>
          )
        }}
      />
      <Tabs.Screen
        name="two"
        options={{
          title: 'Review',
          tabBarIcon: ({ color }) => <TabBarIcon name="photo" color={color} />,
          headerRight: () => (
            <TouchableOpacity
              style={{ paddingRight: 12 }}
              onPress={logout}
            >
              <Ionicons name='log-out' color='#00ACC9' size={24} />
            </TouchableOpacity>
          )
        }}
      />
    </Tabs>
  );
}
