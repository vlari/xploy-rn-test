import React from 'react';
import { View } from '../../components/Themed';
import { ScrollView } from 'react-native-gesture-handler';
import FormContainer from '../../components/FormContainer';

export default function TabOneScreen() {

  return (
    <View style={{ height: '100%' }}>
      <ScrollView>
        <FormContainer />
        <FormContainer />
      </ScrollView>
    </View>
  );
}
