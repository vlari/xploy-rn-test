import { useContext } from 'react';
import { StyleSheet, Image } from 'react-native';
import { Text, View } from '../../components/Themed';
import { FormContext, FormContextType, FormState } from '../context/formContext';
import { ScrollView } from 'react-native-gesture-handler';

export default function TabTwoScreen() {
  const { state } = useContext<FormContextType>(FormContext);
  const { rightTriangle, heptagon, rightTrapezoid }: FormState = state;

  return (
    <ScrollView>
      <View style={styles.container}>
      {
        rightTriangle !== null && rightTriangle !== undefined && (
          <View style={styles.formContainer}>
            <View style={{ flexDirection: 'row' }}>
              <Text style={{ fontWeight: 'bold' }}>Figure:</Text>
              <Text>Figure 1</Text>
            </View>

            <View style={styles.formImageContainer}>
              <Image source={require('../../assets/images/Figure1.png')} style={styles.formImage} />

              <Text style={[styles.textOverlay, styles.hypotenuse]}>{`${rightTriangle.hypotenuse.label}:${rightTriangle.hypotenuse.value}`}</Text>
              <Text style={[styles.textOverlay, styles.height]}>{`${rightTriangle.height.label}:${rightTriangle.height.value}`}</Text>
              <Text style={[styles.textOverlay, styles.base]}>{`${rightTriangle.base.label}:${rightTriangle.base.value}`}</Text>
            </View>
          </View>
        )
      }

      {
        heptagon !== null && heptagon !== undefined && (
          <View style={styles.formContainer}>
            <View style={{ flexDirection: 'row' }}>
              <Text style={{ fontWeight: 'bold' }}>Figure:</Text>
              <Text>Figure 2</Text>
            </View>

            <View style={styles.formImageContainer}>
              <Image source={require('../../assets/images/Figure2.png')} style={styles.formImage} />

              <Text style={[styles.textOverlay, styles.superiorLeg]}>{`${heptagon.superiorLeg.label}:${heptagon?.superiorLeg.value}`}</Text>
              <Text style={[styles.textOverlay, styles.longBase]}>{`${heptagon.longBase.label}:${heptagon?.longBase.value}`}</Text>
              <Text style={[styles.textOverlay, styles.outerLeg]}>{`${heptagon.outerLeg.label}:${heptagon?.outerLeg.value}`}</Text>
              <Text style={[styles.textOverlay, styles.innerLeg]}>{`${heptagon.innerLeg.label}:${heptagon?.innerLeg.value}`}</Text>
              <Text style={[styles.textOverlay, styles.middleLeg]}>{`${heptagon.middleLeg.label}:${heptagon?.middleLeg.value}`}</Text>
              <Text style={[styles.textOverlay, styles.shortBase]}>{`${heptagon.shortBase.label}:${heptagon?.shortBase.value}`}</Text>
              <Text style={[styles.textOverlay, styles.middleBase]}>{`${heptagon.middleBase.label}:${heptagon?.middleBase.value}`}</Text>
            </View>
          </View>
        )
      }

      {
        rightTrapezoid !== null && rightTrapezoid !== undefined && (
          <View style={styles.formContainer}>
            <View style={{ flexDirection: 'row' }}>
              <Text style={{ fontWeight: 'bold' }}>Figure:</Text>
              <Text>Figure 3</Text>
            </View>

            <View style={styles.formImageContainer}>
              <Image source={require('../../assets/images/Figure3.png')} style={styles.formImage} />

              <Text style={[styles.textOverlay, rightTrapezoidStyles.height]}>{`${rightTrapezoid.height.label}:${rightTrapezoid?.height.value}`}</Text>
              <Text style={[styles.textOverlay, rightTrapezoidStyles.longBase]}>{`${rightTrapezoid.longBase.label}:${rightTrapezoid?.longBase.value}`}</Text>
              <Text style={[styles.textOverlay, rightTrapezoidStyles.shortBase]}>{`${rightTrapezoid.shortBase.label}:${rightTrapezoid?.shortBase.value}`}</Text>
              <Text style={[styles.textOverlay, rightTrapezoidStyles.superiorLeg]}>{`${rightTrapezoid.superiorLeg.label}:${rightTrapezoid?.superiorLeg.value}`}</Text>
            </View>
          </View>
        )
      }
    </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  separator: {
    marginVertical: 30,
    height: 1,
    width: '80%',
  },
  formImage: {
    aspectRatio: 1,
    resizeMode: 'contain'
  },
  formImageContainer: {
    paddingBottom: 20
  },
  formContainer: {
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 10,
    position: 'relative'
  },
  formRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  formLabel: {
    fontSize: 18,
    marginRight: 10,
  },
  formTextBox: {
    borderWidth: 1,
    borderColor: 'black',
    padding: 8,
    fontSize: 16,
    width: 200,
  },
  textOverlay: {
    position: 'absolute',
    color: '#000',
    fontSize: 12,
    fontWeight: 'bold'
  },
  hypotenuse: {
    top: 100,
    alignSelf: 'center'
  },
  height: {
    top: '50%',
    alignSelf: 'flex-end'
  },
  base: {
    bottom: 40,
    alignSelf: 'center'
  },
  superiorLeg: {
    top: '30%',
    alignSelf: 'center'
  },
  longBase: {
    bottom: '30%',
    alignSelf: 'center'
  },
  outerLeg: {
    bottom: '45%',
    alignSelf: 'flex-end'
  },
  innerLeg: {
    bottom: '55%',
    right: '15%',
    alignSelf: 'flex-end'
  },
  middleLeg: {
    top: '35%',
    right: 20,
    alignSelf: 'flex-end'
  },
  shortBase: {
    bottom: '55%',
    right: 30,
    alignSelf: 'flex-end'
  },
  middleBase: {
    top: '40%',
    right: 40,
    alignSelf: 'flex-end'
  }
});

const rightTrapezoidStyles = StyleSheet.create({
  height: {
    top: '10%',
    alignSelf: 'center'
  },
  longBase: {
    top: '50%',
    left: -10
  },
  shortBase: {
    top: '30%',
    right: -10,
    alignSelf: 'flex-end'
  },
  superiorLeg: {
    bottom: '40%',
    alignSelf: 'center'
  }
});