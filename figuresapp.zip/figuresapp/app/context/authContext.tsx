import { createContext, Dispatch, ReactNode } from 'react';
import { BasicCredential } from '../types.d';

interface AuthState {
    credentials: BasicCredential | null;
    canRemember: boolean
    isLogin: boolean
}

enum AuthActionType {
  SetCredentials = 'SET_CREDENTIALS',
  SetCanRemember = 'SET_CANREMEMBER',
  SetLogin = 'LOGIN',
  SetLogout = 'LOGOUT',
//   SetIsLogin = 'Set_IsLOGIN'
}

interface SetCredentialsAction {
  type: AuthActionType.SetCredentials;
  payload: BasicCredential;
}
interface SetCanRememberAction {
  type: AuthActionType.SetCanRemember;
  payload: boolean;
}
// interface SetIsLoginAction {
//   type: AuthActionType.SetIsLogin;
//   payload: boolean;
// }
interface SetLoginAction {
  type: AuthActionType.SetLogin;
  payload: { credential: BasicCredential, canRemember: boolean, isLogin: boolean } ;
}

interface SetLogoutAction {
  type: AuthActionType.SetLogout;
}


type AuthAction = SetCredentialsAction | SetCanRememberAction | SetLoginAction | SetLogoutAction;

export interface AuthContextType {
    state: AuthState;
    dispatch: Dispatch<AuthAction>;
    login: (credentials: BasicCredential, canRemember: boolean) => void;
    logout: () => void;
}

const initialState: AuthState = {
  credentials: null,
  canRemember: false,
  isLogin: false
};

const AuthContext = createContext<AuthContextType>({
  state: initialState,
  dispatch: () => null,
  login: () => {},
  logout: () => {}
});

export { AuthContext, AuthState, AuthAction, AuthActionType, initialState };