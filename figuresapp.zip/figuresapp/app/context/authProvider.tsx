import React, { useReducer, ReactNode } from 'react';
import { AuthActionType, AuthContext, initialState } from './authContext';
import authReducer from './authReducer';
import { BasicCredential } from '../types';

interface AppContextProviderProps {
    children: ReactNode;
}

const AuthContextProvider: React.FC<AppContextProviderProps> = ({ children }) => {
    const [state, dispatch] = useReducer(authReducer, initialState);

    const login = (credentials: BasicCredential, canRemember: boolean) => {
        if (credentials.username === 'John0' && credentials.password === '123') {
            dispatch({ type: AuthActionType.SetLogin, payload: { credential: credentials, canRemember: canRemember, isLogin: true } });
        }
    }

    const logout = () => {
        dispatch({ type: AuthActionType.SetLogout });
    }

    return (
        <AuthContext.Provider value={{ state, dispatch, login, logout }}>
            {children}
        </AuthContext.Provider>
    );
};

export { AuthContextProvider };