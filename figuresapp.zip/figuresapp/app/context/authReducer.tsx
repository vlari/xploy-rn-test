import { AuthState, AuthAction, AuthActionType } from './authContext';

const authReducer = (state: AuthState, action: AuthAction): AuthState => {
  switch (action.type) {
    case AuthActionType.SetCredentials:
      return { ...state, credentials: action.payload };
    case AuthActionType.SetCanRemember:
      return { ...state, canRemember: action.payload };
      case AuthActionType.SetLogin:
        return { ...state, canRemember: action.payload.canRemember, credentials: action.payload.credential, isLogin: action.payload.isLogin };
      case AuthActionType.SetLogout:
        return { ...state, isLogin: false, canRemember: false };
    default:
      return state;
  }
};

export default authReducer;