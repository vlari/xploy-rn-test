import { createContext, Dispatch, ReactNode } from 'react';
import { Heptagon, RightTrapezoid, RightTriangle } from '../types.d';

interface FormState {
    rightTriangle: RightTriangle | null;
    rightTrapezoid: RightTrapezoid | null;
    heptagon: Heptagon | null;
}

enum ActionType {
  SetRightTriangle = 'SET_RIGHT_TRIANGLE',
  DeleteRightTriangle = 'DELETE_RIGHT_TRIANGLE',
  SetRightTrapezoid = 'SET_RIGHT_TRAPEZOID',
  DeleteRightTrapezoid = 'DELETE_RIGHT_TRAPEZOID',
  SetHeptagon = 'SET_HEPTAGON',
  DeleteHeptagon = 'DELETE_HEPTAGON'
}

interface SetRightTriangleAction {
  type: ActionType.SetRightTriangle;
  payload: RightTriangle;
}

interface DeleteRightTriangleAction {
  type: ActionType.DeleteRightTriangle;
}

interface SetRightTrapezoidAction {
  type: ActionType.SetRightTrapezoid;
  payload: RightTrapezoid;
}

interface DeleteRightTrapezoidAction {
  type: ActionType.DeleteRightTrapezoid;
}

interface SetHeptagonAction {
  type: ActionType.SetHeptagon;
  payload: Heptagon;
}

interface DeleteHeptagonAction {
  type: ActionType.DeleteHeptagon;
}

type FormAction = SetRightTriangleAction | DeleteRightTriangleAction | SetRightTrapezoidAction | DeleteRightTrapezoidAction | SetHeptagonAction | DeleteHeptagonAction;

export interface FormContextType {
    state: FormState;
    dispatch: Dispatch<FormAction>;
}

const initialState: FormState = {
  rightTriangle: null,
  rightTrapezoid: null,
  heptagon: null
};

const FormContext = createContext<FormContextType>({
  state: initialState,
  dispatch: () => null
});

export { FormContext, FormState, FormAction, ActionType, initialState };