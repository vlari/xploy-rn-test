import React, { useReducer, createContext, ReactNode, Dispatch } from 'react';
import { FormContext, initialState } from './formContext';
import formReducer from './formReducer';

interface AppContextProviderProps {
    children: ReactNode;
}

const FormContextProvider: React.FC<AppContextProviderProps> = ({ children }) => {
    const [state, dispatch] = useReducer(formReducer, initialState);

    return (
        <FormContext.Provider value={{ state, dispatch }}>
            {children}
        </FormContext.Provider>
    );
};

export { FormContextProvider };