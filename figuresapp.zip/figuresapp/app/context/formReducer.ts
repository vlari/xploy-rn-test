import { FormState, FormAction, ActionType } from './formContext';

const formReducer = (state: FormState, action: FormAction): FormState => {
  switch (action.type) {
    case ActionType.SetRightTriangle:
      return { ...state, rightTriangle: action.payload };
    case ActionType.DeleteRightTriangle:
      return { ...state, rightTriangle: null };
    case ActionType.SetRightTrapezoid:
      return { ...state, rightTrapezoid: action.payload };
    case ActionType.DeleteRightTrapezoid:
      return { ...state, rightTrapezoid: null };
    case ActionType.SetHeptagon:
      return { ...state, heptagon: action.payload };
    case ActionType.DeleteHeptagon:
      return { ...state, heptagon: null };
    default:
      return state;
  }
};

export default formReducer;