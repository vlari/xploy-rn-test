export enum FigureType {
  RightTriangle = 'rightTriangle',
  RightTrapezoid = 'rightTrapezoid',
  Heptagon = 'heptagon',
  None = "none"
}

interface Credential {
  username: string;
  password: string;
}

export class BasicCredential implements Credential {
  username: string;
  password: string;

  constructor(username: string = '', password: string = '') {
    this.username = username;
    this.password = password;
  } 
}

export interface Figure {
  name: string;
  sideCount: number;
}

export interface Side {
  value: number;
  name: string;
  label: string;
}

export class RightTriangle implements Figure {
  base: Side;
  height: Side;
  hypotenuse: Side;

  constructor(
    baseValue: number = 0,
    heightValue: number = 0,
    hypotenuseValue: number = 0
  ) {
    this.base = { value: baseValue, name: 'Base', label: 'a' };
    this.height = { value: heightValue, name: 'Height', label: 'b' };
    this.hypotenuse = { value: hypotenuseValue, name: 'Hypotenuse', label: 'c' };
  }

  get name(): string {
    return 'Figure 1';
  }

  get sideCount(): number {
    return 3;
  }

  getSides(): Side[] {
    const mirror = Object.entries(this);
    const sides: Side[] = [];

    for (const [_, value] of mirror) {
      if (this.isSide(value)) {
        sides.push(value);
      }
    }

    return sides;
  }

  calculateValue(): void {
    if (this.base.value === 0 && this.height.value === 0 && this.hypotenuse.value === 0) return;
    const missingSide = this.findMissing();

    if (!missingSide) {
      return;
    }

    switch (missingSide.label) {
      case 'c':
        this.hypotenuse.value = this.calculateHypotenuse();
        break;
      case 'a':
      case 'b':
        const sideValue = this.calculateSide();
        if (this.base.value === 0) {
          this.base.value = sideValue;
        } else {
          this.height.value = sideValue;
        }
        break;
      default:
        console.log('Non Operation');
    }
  }

  private findMissing(): Side | null {
    const mirror = Object.entries(this);
    for (const [_, value] of mirror) {
      if (this.isSide(value) && (value as Side).value === 0) {
        return value as Side;
      }
    }

    return null;
  }

  private calculateHypotenuse(): number {
    return Math.sqrt(Math.pow(this.base.value, 2) + Math.pow(this.height.value, 2));
  }

  private calculateSide(): number {
    const side = this.base.value === 0 ? this.height : this.base;
    return Math.sqrt(Math.abs(Math.pow(this.hypotenuse.value, 2) - Math.pow(side.value, 2)));
  }

  private isSide(value: any): value is Side {
    return typeof value === 'object' && 'value' in value && 'name' in value && 'label' in value;
  }
}

export class RightTrapezoid implements Figure {
  longBase: Side;
  shortBase: Side;
  height: Side;
  superiorLeg: Side;

  constructor(
    longBaseValue: number = 0,
    shortBaseValue: number = 0,
    heightValue: number = 0,
    superiorLegValue: number = 0
  ) {
    this.longBase = { value: longBaseValue, name: "Long Base", label: "d" };
    this.shortBase = { value: shortBaseValue, name: "Short Base", label: "b" };
    this.height = { value: heightValue, name: "Height", label: "c" };
    this.superiorLeg = { value: superiorLegValue, name: "Superior Leg", label: "a" };
  }

  get name(): string {
    return "Figure 3";
  }

  get sideCount(): number {
    return 4;
  }

  calculateValue(): void {
    if (this.longBase.value === 0 && 
      this.shortBase.value === 0 && 
      this.height.value === 0 && this.superiorLeg.value === 0) return;
    const missingSide = this.findMissing();
    if (!missingSide) return;

    switch (missingSide.label) {
      case "a":
        this.superiorLeg.value = this.calculateSuperiorLeg();
        break;
      case "b":
        this.shortBase.value = this.calculateShortBase();
        break;
      case "c":
        this.height.value = this.calculateHeight();
        break;
      case "d":
        this.longBase.value = this.calculateLongBase();
        break;
      default:
        console.log("Non Operation");
    }
  }

  private findMissing(): Side | null {
    for (const prop in this) {
      if (this.hasOwnProperty(prop)) {
        const side = (this as any)[prop] as Side;
        if (side.value === 0) {
          return side;
        }
      }
    }

    return null;
  }

  private calculateSuperiorLeg(): number {
    const newLeg = this.longBase.value - this.shortBase.value;
    return this.calculateHypotenuse(newLeg, this.height.value);
  }

  private calculateHeight(): number {
    const newLeg = this.longBase.value - this.shortBase.value;
    return this.calculateSide(this.superiorLeg.value, newLeg);
  }

  private calculateLongBase(): number {
    const partialBase = this.calculateSide(this.superiorLeg.value, this.height.value);
    return partialBase + this.shortBase.value;
  }

  private calculateShortBase(): number {
    const partialBase = this.calculateSide(this.superiorLeg.value, this.height.value);
    return this.longBase.value - partialBase;
  }

  private calculateHypotenuse(a: number, b: number): number {
    return Math.sqrt(Math.pow(a, 2) + Math.pow(b, 2));
  }

  private calculateSide(hypotenuse: number, side: number): number {
    return Math.sqrt(Math.abs(Math.pow(hypotenuse, 2) - Math.pow(side, 2)));
  }
}

export class Heptagon implements Figure {
  longBase: Side;
  superiorLeg: Side;
  outerLeg: Side;
  innerLeg: Side;
  middleLeg: Side;
  middleBase: Side;
  shortBase: Side;

  constructor(
    longBaseValue: number = 0,
    superiorLegValue: number = 0,
    outerLegValue: number = 0,
    innerLegValue: number = 0,
    middleLegValue: number = 0,
    middleBaseValue: number = 0,
    shortBaseValue: number = 0
  ) {
    this.longBase = { value: longBaseValue, name: "Long Base", label: "a" };
    this.outerLeg = { value: outerLegValue, name: "Outer Leg", label: "b" };
    this.middleBase = { value: middleBaseValue, name: "Middle Base", label: "c" };
    this.innerLeg = { value: innerLegValue, name: "Inner Leg", label: "d" };
    this.shortBase = { value: shortBaseValue, name: "Short Base", label: "e" };
    this.middleLeg = { value: middleLegValue, name: "Middle Leg", label: "f" };
    this.superiorLeg = { value: superiorLegValue, name: "Superior Leg", label: "g" };
  }

  get name(): string {
    return "Figure 2";
  }

  get sideCount(): number {
    return 7;
  }

  calculateValue(): void {
    if (this.longBase.value === 0 && 
      this.outerLeg.value === 0 && 
      this.middleBase.value === 0 && 
      this.innerLeg.value === 0 && 
      this.shortBase.value === 0 && 
      this.middleLeg.value === 0 && this.superiorLeg.value === 0) return;
    const missingSide = this.findMissing();

    if (!missingSide) return;

    switch (missingSide.label) {
      case "a":
        this.longBase.value = this.calculateLongBase();
        break;
      case "b":
        this.outerLeg.value = this.calculateOuterLeg();
        break;
      case "c":
        this.middleBase.value = this.calculateMiddleBase();
        break;
      case "d":
        this.innerLeg.value = this.calculateInnerLeg();
        break;
      case "e":
        this.shortBase.value = this.calculateShortBase();
        break;
      case "f":
        this.middleLeg.value = this.calculateMiddleLeg();
        break;
      case "g":
        this.superiorLeg.value = this.calculateSuperiorLeg();
        break;
      default:
        console.log("Non Operation");
    }
  }

  private calculateLongBase(): number {
    const numerator = Math.pow(this.superiorLeg.value, 2);
    const denominator = Math.pow(this.outerLeg.value + this.innerLeg.value + this.middleLeg.value, 2);
    const result = Math.sqrt(numerator / denominator + this.middleBase.value - this.shortBase.value);
    return result;
  }

  private calculateSuperiorLeg(): number {
    const result = Math.sqrt(
      Math.pow(this.longBase.value - this.middleBase.value + this.shortBase.value, 2) +
        Math.pow(this.outerLeg.value + this.innerLeg.value + this.middleLeg.value, 2)
    );
    return result;
  }

  private calculateOuterLeg(): number {
    const numerator = Math.pow(this.superiorLeg.value, 2) - Math.pow(this.longBase.value - this.middleBase.value + this.shortBase.value, 2);
    const denominator = Math.pow(this.innerLeg.value + this.middleLeg.value, 2);
    const result = Math.sqrt(numerator / denominator);
    return result;
  }

  private calculateMiddleBase(): number {
    const numerator = Math.pow(this.superiorLeg.value, 2) - Math.pow(this.outerLeg.value + this.innerLeg.value + this.middleLeg.value, 2);
    const result = Math.sqrt(numerator) + this.shortBase.value - this.longBase.value;
    return result;
  }

  private calculateShortBase(): number {
    const shortBaseSquared =
      Math.pow(this.outerLeg.value + this.innerLeg.value + this.middleLeg.value, 2) -
      Math.pow(this.superiorLeg.value, 2) / Math.pow(this.longBase.value - this.middleBase.value, 2);
    if (shortBaseSquared < 0) {
      // If shortBaseSquared is negative, there is no real solution
      return 0;
    }
    return Math.sqrt(shortBaseSquared);
  }

  private calculateInnerLeg(): number {
    const numerator = Math.pow(this.superiorLeg.value, 2) - Math.pow(this.longBase.value - this.middleBase.value + this.shortBase.value, 2);
    const denominator = Math.pow(this.outerLeg.value + this.middleLeg.value, 2);
    const result = Math.sqrt(numerator / denominator);
    return result;
  }

  private calculateMiddleLeg(): number {
    const numerator = Math.pow(this.superiorLeg.value, 2) - Math.pow(this.longBase.value - this.middleBase.value + this.shortBase.value, 2);
    const denominator = Math.pow(this.outerLeg.value + this.innerLeg.value, 2);
    const result = Math.sqrt(numerator / denominator);
    return result;
  }

  private findMissing(): Side | null {
    for (const prop in this) {
      if (this.hasOwnProperty(prop)) {
        const side = (this as any)[prop] as Side;
        if (side.value === 0) {
          return side;
        }
      }
    }

    return null;
  }

  private isEmpty(): boolean {
    let hasChanged = false;
    for (const prop in this) {
      if (this.hasOwnProperty(prop)) {
        const side = (this as any)[prop] as Side;
        if (side.value !== 0) {
          hasChanged = true;
          break;
        }
      }
    }

    return hasChanged;
  }
}