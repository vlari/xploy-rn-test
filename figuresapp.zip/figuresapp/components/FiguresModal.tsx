import React, { useState } from 'react';
import {
    TouchableOpacity,
    StyleSheet,
    Modal,
    FlatList,
    Image
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Text, View } from './Themed';
import { FigureType } from '../app/types.d'

interface Props {
    isModalVisible: boolean
    setModalVisibility: (value: boolean) => void
    setSelectedFigure: (value: FigureType) => void
}

const FiguresModal = ({ isModalVisible, setModalVisibility, setSelectedFigure }: Props) => {
    const data = [
        { id: '1', image: require('../assets/images/Figure1.png'), text: 'Figure 1', type: FigureType.RightTriangle },
        { id: '2', image: require('../assets/images/Figure2.png'), text: 'Figure 2', type: FigureType.Heptagon },
        { id: '3', image: require('../assets/images/Figure3.png'), text: 'Figure 3', type: FigureType.RightTrapezoid },
    ];

    const onSelectFigure = (figure: FigureType) => {
        setSelectedFigure(figure)
        setModalVisibility(false)
    }

    const renderItem = ({ item }) => (
        <View style={styles.itemContainer}>
            <TouchableOpacity onPress={() => onSelectFigure(item.type)}>
                <Text style={styles.imageText}>{item.text}</Text>
                <Image source={item.image} style={styles.image} />
            </TouchableOpacity>
        </View>
    );

    return (
        <Modal animationType='slide' visible={isModalVisible}>
            <View style={{ flex: 1, backgroundColor: "white", paddingTop: 60 }}>

                <TouchableOpacity onPress={() => setModalVisibility(false)} style={{ position: 'absolute', top: 60, left: 10, zIndex: 1 }}>
                    <Ionicons name="close" size={24} color="black" />
                </TouchableOpacity>

                <FlatList
                    data={data}
                    renderItem={renderItem}
                    keyExtractor={(item) => item.id}
                    numColumns={1}
                />

            </View>
        </Modal>
    )
}

export default FiguresModal

const styles = StyleSheet.create({
    itemContainer: {
        marginBottom: 20,
        alignItems: 'center',
    },
    image: {
        // flex: 1,
        aspectRatio: 1,
        resizeMode: 'contain'
    },
    imageText: {
        marginTop: 10,
        fontSize: 16,
    },
});