import React, { useState, useEffect, useContext } from 'react'
import {
    TouchableOpacity,
    StyleSheet
} from 'react-native';
import { Text, View } from './Themed';
import { FigureType } from '../app/types.d';
import RightTriangleForm from './RightTriangleForm';
import HeptagonForm from './HeptagonForm';
import RightTrapezoidForm from './RightTrapezoidForm';
import FiguresModal from './FiguresModal';
import { FormContext, FormContextType, FormState } from '../app/context/formContext';

const FormContainer = () => {
    const [selectedFigure, setSelectedFigure] = useState<FigureType>(FigureType.None);
    const [isModalVisible, setModalVisibility] = useState(false);

    const { state } = useContext<FormContextType>(FormContext);
    const { rightTriangle, heptagon, rightTrapezoid }: FormState = state;

    const canAdd = (figure: FigureType): boolean => {
        if (figure == FigureType.RightTriangle) {
            return rightTriangle === null;
        } else if (figure == FigureType.Heptagon) {
            return heptagon === null;
        } else if (figure == FigureType.RightTrapezoid) {
            return rightTrapezoid === null;
        }

        return false;
    }

    useEffect(() => {
        if (rightTriangle == null && selectedFigure == FigureType.RightTriangle) {
            setSelectedFigure(FigureType.None);
        } else if (heptagon == null && selectedFigure == FigureType.Heptagon) {
            setSelectedFigure(FigureType.None);
        } else if (rightTrapezoid == null && selectedFigure == FigureType.RightTrapezoid) {
            setSelectedFigure(FigureType.None);
        }

    }, [rightTriangle, heptagon, rightTrapezoid])

    let conditionalContent: React.ReactElement | null = null;
    if (selectedFigure === FigureType.RightTriangle) {
        conditionalContent = (
            <RightTriangleForm />
        );
    } else if (selectedFigure === FigureType.Heptagon ) {
        conditionalContent = (
            <HeptagonForm />
        );
    } else if (selectedFigure === FigureType.RightTrapezoid ) {
        conditionalContent = (
            <RightTrapezoidForm />
        );
    }

    const onSelectFigure = (figure: FigureType) => {
        if (canAdd(figure)) {
            setSelectedFigure(figure);
        }
    }

    return (
        <View>
            <View style={styles.container}>
                <Text style={styles.headlineText}>Figure</Text>
                <TouchableOpacity
                    onPress={() => setModalVisibility(true)}
                    style={styles.button}
                >
                    <Text style={styles.buttonText}>Pick Figure</Text>
                </TouchableOpacity>
            </View>

            {conditionalContent}

            <FiguresModal
                isModalVisible={isModalVisible}
                setModalVisibility={() => setModalVisibility(false)}
                setSelectedFigure={(figure: FigureType) => onSelectFigure(figure)}
            />
        </View>
    )
}

export default FormContainer

const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 16,
        paddingVertical: 16
    },
    headlineText: {
        fontSize: 20,
        fontWeight: 'bold',
        color: 'black',
    },
    button: {
        flex: 1,
        backgroundColor: 'transparent',
        paddingHorizontal: 16,
        paddingVertical: 8,
        borderRadius: 2,
        borderWidth: 2,
        borderColor: 'grey',
        marginLeft: 8,
    },
    buttonText: {
        color: 'black',
        textAlign: 'center',
    }
});
