import React, { useState, useEffect, useContext } from 'react'
import {
  StyleSheet,
  Image,
  TextInput
} from 'react-native';
import { Text, View } from './Themed';
import { ActionType, FormContext } from '../app/context/formContext';
import { Heptagon } from '../app/types.d';
import { Ionicons } from '@expo/vector-icons';
import { TouchableOpacity } from 'react-native-gesture-handler';

const HeptagonForm = () => {
  const { dispatch } = useContext(FormContext);
  const [superiorLeg, setSuperiorLeg] = useState('0');
  const [longBase, setLongBase] = useState('0');
  const [outerLeg, setOuterLeg] = useState('0');
  const [innerLeg, setInnerLeg] = useState('0');
  const [middleLeg, setMiddleLeg] = useState('0');
  const [shortBase, setShortBase] = useState('0');
  const [middleBase, setMiddleBase] = useState('0');

  useEffect(() => {
    const newHeptagon = new Heptagon(
        parseFloat(longBase) || 0,
        parseFloat(superiorLeg) || 0,
        parseFloat(outerLeg) || 0,
        parseFloat(innerLeg) || 0,
        parseFloat(middleLeg) || 0,
        parseFloat(middleBase) || 0,
        parseFloat(shortBase) || 0
    );

    newHeptagon.calculateValue();

    dispatch({ type: ActionType.SetHeptagon, payload: newHeptagon });
  }, [longBase, superiorLeg, outerLeg, innerLeg, middleLeg, middleBase, shortBase, dispatch]);

  const onDelete = () => {
    dispatch({ type: ActionType.DeleteHeptagon });
  }

  return (
    <View style={styles.formContainer}>

      <View style={styles.formImageContainer}>
        <Image source={require('../assets/images/Figure2.png')} style={styles.formImage} />

        <View style={{ position: 'absolute', right: -50, top: '50%' }}>
          <TouchableOpacity onPress={() => onDelete()}>
            <Ionicons name='trash' color='red' size={20} />
          </TouchableOpacity>
        </View>
        <Text style={[styles.textOverlay, styles.superiorLeg]}>g</Text>
        <Text style={[styles.textOverlay, styles.longBase]}>a</Text>
        <Text style={[styles.textOverlay, styles.outerLeg]}>b</Text>
        <Text style={[styles.textOverlay, styles.innerLeg]}>d</Text>
        <Text style={[styles.textOverlay, styles.middleLeg]}>f</Text>
        <Text style={[styles.textOverlay, styles.shortBase]}>c</Text>
        <Text style={[styles.textOverlay, styles.middleBase]}>e</Text>
      </View>

      <Text style={{ fontWeight: 'bold', alignSelf: 'flex-start', padding: 20 }}>Measurements</Text>

      <View style={styles.formRow}>
        <Text style={styles.formLabel}>a</Text>
        <TextInput style={styles.formTextBox} placeholder="" onChangeText={newText => setLongBase(newText)} />
      </View>
      <View style={styles.formRow}>
        <Text style={styles.formLabel}>b</Text>
        <TextInput style={styles.formTextBox} placeholder="" onChangeText={newText => setOuterLeg(newText)} />
      </View>
      <View style={styles.formRow}>
        <Text style={styles.formLabel}>c</Text>
        <TextInput style={styles.formTextBox} placeholder="" onChangeText={newText => setMiddleBase(newText)} />
      </View>
      <View style={styles.formRow}>
        <Text style={styles.formLabel}>d</Text>
        <TextInput style={styles.formTextBox} placeholder="" onChangeText={newText => setInnerLeg(newText)} />
      </View>
      <View style={styles.formRow}>
        <Text style={styles.formLabel}>e</Text>
        <TextInput style={styles.formTextBox} placeholder="" onChangeText={newText => setShortBase(newText)} />
      </View>
      <View style={styles.formRow}>
        <Text style={styles.formLabel}>f</Text>
        <TextInput style={styles.formTextBox} placeholder="" onChangeText={newText => setMiddleLeg(newText)} />
      </View>
      <View style={styles.formRow}>
        <Text style={styles.formLabel}>g</Text>
        <TextInput style={styles.formTextBox} placeholder="" onChangeText={newText => setSuperiorLeg(newText)} />
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  formImage: {
    aspectRatio: 1,
    resizeMode: 'contain'
  },
  formImageContainer: {
    paddingBottom: 20
  },
  formContainer: {
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 10,
    position: 'relative'
  },
  formRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  formLabel: {
    fontSize: 18,
    marginRight: 10,
  },
  formTextBox: {
    borderWidth: 1,
    borderColor: 'black',
    padding: 8,
    fontSize: 16,
    width: 200,
  },
  textOverlay: {
    position: 'absolute',
    color: '#000',
    fontSize: 12,
    fontWeight: 'bold'
  },
  superiorLeg: {
    top: '30%',
    alignSelf: 'center'
  },
  longBase: {
    bottom: '30%',
    alignSelf: 'center'
  },
  outerLeg: {
    bottom: '45%',
    alignSelf: 'flex-end'
  },
  innerLeg: {
    bottom: '55%',
    right: '15%',
    alignSelf: 'flex-end'
  },
  middleLeg: {
    top: '35%',
    right: 20,
    alignSelf: 'flex-end'
  },
  shortBase: {
    bottom: '55%',
    right: 30,
    alignSelf: 'flex-end'
  },
  middleBase: {
    top: '40%',
    right: 40,
    alignSelf: 'flex-end'
  }
});

export default HeptagonForm