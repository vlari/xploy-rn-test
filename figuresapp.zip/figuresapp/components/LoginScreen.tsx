import React, { useContext, useState } from 'react';
import { View, ScrollView, Image, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { AuthContext } from '../app/context/authContext';
import { BasicCredential } from '../app/types.d';
import { CheckBox } from 'react-native-elements/dist/checkbox/CheckBox';

const LoginScreen = () => {
    const { login, state } = useContext(AuthContext);
    const [username, setUsername] = useState<string>('');
    const [password, setPassword] = useState<string>('');
    const [canRemember, setCanRemember] = useState<boolean>(false);

    const onLogin = () => {
        if (username.length === 0 || password.length === 0) {
            Alert.alert(
                'Login',
                'Wrong credentials!',
                [{ text: 'OK', onPress: () => console.log('Dismissed') }]
            );
            return;
        }
        const credentials: BasicCredential = new BasicCredential(username, password);
        login(credentials, canRemember);
    }

    const toggleCheckbox = () => setCanRemember(!canRemember);

    return (
        <ScrollView contentContainerStyle={styles.container}>
            <View style={styles.centered}>
                <Image source={require('../assets/images/figuresicon.png')} style={styles.logo} />
            </View>

            <View style={styles.inputContainer}>
                <View style={styles.inputWrapper}>
                    <Text style={styles.label}>Username</Text>
                    <TextInput style={styles.input} placeholder="Enter your username" onChangeText={newText => setUsername(newText)} />
                </View>

                <View style={styles.inputWrapper}>
                    <Text style={styles.label}>Password</Text>
                    <TextInput style={styles.input} placeholder="Enter your password" secureTextEntry={true} onChangeText={newText => setPassword(newText)} />
                </View>

                <View style={styles.checkboxContainer}>
                    <CheckBox checked={canRemember} onPress={toggleCheckbox} />
                    <Text>Remember me</Text>
                </View>

                <TouchableOpacity style={styles.loginButton} onPress={onLogin}>
                    <Text style={styles.buttonText}>Log In</Text>
                </TouchableOpacity>
            </View>
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    container: {
        flexGrow: 1,
        justifyContent: 'center',
        padding: 16,
    },
    centered: {
        alignItems: 'center',
    },
    logo: {
        width: 200,
        height: 200,
        resizeMode: 'contain',
    },
    inputContainer: {
        marginTop: 20,
    },
    inputWrapper: {
        marginBottom: 16,
    },
    label: {
        marginBottom: 8,
    },
    input: {
        borderWidth: 1,
        borderColor: '#ccc',
        borderRadius: 8,
        padding: 10,
    },
    checkboxContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 16,
    },
    loginButton: {
        backgroundColor: '#00ACC9',
        paddingVertical: 16,
        borderRadius: 8,
    },
    buttonText: {
        color: 'white',
        textAlign: 'center',
        fontSize: 16,
    },
});

export default LoginScreen;