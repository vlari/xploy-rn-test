import React, { useState, useEffect, useContext } from 'react'
import {
  StyleSheet,
  Image,
  TextInput
} from 'react-native';
import { Text, View } from './Themed';
import { ActionType, FormContext } from '../app/context/formContext';
import { RightTrapezoid } from '../app/types.d';
import { Ionicons } from '@expo/vector-icons';
import { TouchableOpacity } from 'react-native-gesture-handler';

const RightTrapezoidForm = () => {
  const { dispatch } = useContext(FormContext);
  const [superiorLeg, setSuperiorLeg] = useState('0');
  const [height, setHeight] = useState('0');
  const [longBase, setLongBase] = useState('0');
  const [shortBase, setShortBase] = useState('0');

  useEffect(() => {
    const newRightTrapezoid = new RightTrapezoid(
        parseFloat(longBase) || 0,
        parseFloat(shortBase) || 0,
        parseFloat(height) || 0,
        parseFloat(superiorLeg) || 0
    );

    newRightTrapezoid.calculateValue();

    dispatch({ type: ActionType.SetRightTrapezoid, payload: newRightTrapezoid });
  }, [longBase, shortBase, height, superiorLeg, dispatch]);

  const onDelete = () => {
    dispatch({ type: ActionType.DeleteRightTrapezoid });
  }

  return (
    <View style={styles.formContainer}>
      <View style={styles.formImageContainer}>
        <Image source={require('../assets/images/Figure3.png')} style={styles.formImage} />

        <View style={{ position: 'absolute', right: -50, top: '50%' }}>
          <TouchableOpacity onPress={() => onDelete()}>
            <Ionicons name='trash' color='red' size={20} />
          </TouchableOpacity>
        </View>
        <Text style={[styles.textOverlay, styles.height]}>c</Text>
        <Text style={[styles.textOverlay, styles.longBase]}>d</Text>
        <Text style={[styles.textOverlay, styles.shortBase]}>b</Text>
        <Text style={[styles.textOverlay, styles.superiorLeg]}>a</Text>
      </View>

      <Text style={{ fontWeight: 'bold', alignSelf: 'flex-start', padding: 20 }}>Measurements</Text>

      <View style={styles.formRow}>
        <Text style={styles.formLabel}>a</Text>
        <TextInput style={styles.formTextBox} placeholder="" onChangeText={newText => setSuperiorLeg(newText)} />
      </View>
      <View style={styles.formRow}>
        <Text style={styles.formLabel}>b</Text>
        <TextInput style={styles.formTextBox} placeholder="" onChangeText={newText => setShortBase(newText)} />
      </View>
      <View style={styles.formRow}>
        <Text style={styles.formLabel}>c</Text>
        <TextInput style={styles.formTextBox} placeholder="" onChangeText={newText => setHeight(newText)} />
      </View>
      <View style={styles.formRow}>
        <Text style={styles.formLabel}>d</Text>
        <TextInput style={styles.formTextBox} placeholder="" onChangeText={newText => setLongBase(newText)} />
      </View>

    </View>
  )
}

const styles = StyleSheet.create({
  formImage: {
    aspectRatio: 1,
    resizeMode: 'contain'
  },
  formImageContainer: {
    paddingBottom: 20
  },
  formContainer: {
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 10,
    position: 'relative'
  },
  formRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  formLabel: {
    fontSize: 18,
    marginRight: 10,
  },
  formTextBox: {
    borderWidth: 1,
    borderColor: 'black',
    padding: 8,
    fontSize: 16,
    width: 200,
  },
  textOverlay: {
    position: 'absolute',
    color: '#000',
    fontSize: 12,
    fontWeight: 'bold'
  },
  height: {
    top: '10%',
    alignSelf: 'center'
  },
  longBase: {
    top: '50%',
    left: -10
  },
  shortBase: {
    top: '30%',
    right: -10,
    alignSelf: 'flex-end'
  },
  superiorLeg: {
    bottom: '40%',
    alignSelf: 'center'
  }
});

export default RightTrapezoidForm