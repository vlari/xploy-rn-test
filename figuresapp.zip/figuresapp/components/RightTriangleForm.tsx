import React, { useState, useEffect, useContext } from 'react'
import {
    StyleSheet,
    Image,
    TextInput
} from 'react-native';
import { Text, View } from './Themed';
import { ActionType, FormContext } from '../app/context/formContext';
import { RightTriangle } from '../app/types.d';
import { Ionicons } from '@expo/vector-icons';
import { TouchableOpacity } from 'react-native-gesture-handler';

const RightTriangleForm = () => {
    const { dispatch } = useContext(FormContext);
    const [hypotenuse, setHypotenuse] = useState('0');
    const [height, setHeight] = useState('0');
    const [base, setBase] = useState('0');

    useEffect(() => {
        const newRightRectangle = new RightTriangle(
            parseFloat(base) || 0,
            parseFloat(height) || 0,
            parseFloat(hypotenuse) || 0
        );

        newRightRectangle.calculateValue();

        dispatch({ type: ActionType.SetRightTriangle, payload: newRightRectangle });
      }, [base, height, hypotenuse, dispatch]);

      const onDelete = () => {
        dispatch({ type: ActionType.DeleteRightTriangle });
      }

    return (
        <View style={styles.formContainer}>
            <View style={styles.formImageContainer}>
                <Image source={require('../assets/images/Figure1.png')} style={styles.formImage} />

                <View style={{ position: 'absolute', right: -50, top: '50%' }}>
                    <TouchableOpacity onPress={() => onDelete()}>
                        <Ionicons name='trash' color='red' size={24}/>
                    </TouchableOpacity>
                </View>
                <Text style={[styles.textOverlay, styles.hypotenuse]}>c</Text>
                <Text style={[styles.textOverlay, styles.height]}>b</Text>
                <Text style={[styles.textOverlay, styles.base]}>a</Text>
            </View>

            <Text style={{ fontWeight: 'bold', alignSelf: 'flex-start', padding: 20 }}>Measurements</Text>

            <View style={styles.formRow}>
                <Text style={styles.formLabel}>a</Text>
                <TextInput style={styles.formTextBox} placeholder="" onChangeText={newText => setBase(newText)} />
            </View>
            <View style={styles.formRow}>
                <Text style={styles.formLabel}>b</Text>
                <TextInput style={styles.formTextBox} placeholder="" onChangeText={newText => setHeight(newText)} />
            </View>
            <View style={styles.formRow}>
                <Text style={styles.formLabel}>c</Text>
                <TextInput style={styles.formTextBox} placeholder="" onChangeText={newText => setHypotenuse(newText)} />
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    formImage: {
        aspectRatio: 1,
        resizeMode: 'contain'
    },
    formImageContainer: {
        paddingBottom: 20
    },
    formContainer: {
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: 10,
        position: 'relative'
    },
    formRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 20,
    },
    formLabel: {
        fontSize: 18,
        marginRight: 10,
    },
    formTextBox: {
        borderWidth: 1,
        borderColor: 'black',
        padding: 8,
        fontSize: 16,
        width: 200,
    },
    textOverlay: {
        position: 'absolute',
        color: '#000',
        fontSize: 12,
        fontWeight: 'bold'
    },
    hypotenuse: {
        top: 100,
        alignSelf: 'center'
    },
    height: {
        top: '50%',
        alignSelf: 'flex-end'
    },
    base: {
        bottom: 40,
        alignSelf: 'center'
    }
});

export default RightTriangleForm